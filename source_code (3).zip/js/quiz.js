/**
 * 诊断测验管理模块
 */

// 管理诊断测验状态
const quizState = {
  questions: [],        // 问题列表
  currentQuestionIndex: 0, // 当前问题索引
  answers: {},          // 用户回答 (问题ID => 选择的回答索引)
  parentMode: false,    // 是否为亲子模式
  childResults: null,   // 孩子的诊断结果（亲子模式用）
  parentResults: null   // 家长的诊断结果（亲子模式用）
};

/**
 * 加载问题数据的函数
 * @returns {Promise} 加载问题数据的Promise
 */
async function loadQuestions() {
  try {
    const response = await fetch('data/questions.json');
    if (!response.ok) {
      throw new Error('加载问题数据失败');
    }
    const data = await response.json();
    quizState.questions = data.questions;
    return quizState.questions;
  } catch (error) {
    console.error('问题数据加载错误:', error);
    // 显示错误报告
    showErrorReport('问题数据加载错误', 
                    '无法执行诊断', 
                    '请刷新页面或稍后重试');
    return [];
  }
}

/**
 * 开始诊断的函数
 * @param {boolean} isParentMode - 是否为亲子模式
 */
function startQuiz(isParentMode = false) {
  // 重置状态
  quizState.currentQuestionIndex = 0;
  quizState.answers = {};
  quizState.parentMode = isParentMode;
  
  if (isParentMode && !quizState.childResults) {
    // 孩子用的诊断模式
    showScreen('quiz-screen');
  } else if (isParentMode && quizState.childResults) {
    // 家长用的诊断模式
    showScreen('quiz-screen');
  } else {
    // 普通诊断模式
    showScreen('quiz-screen');
  }
  
  displayCurrentQuestion();
}

/**
 * 显示当前问题的函数
 */
function displayCurrentQuestion() {
  if (quizState.questions.length === 0) {
    console.error('问题尚未加载');
    return;
  }
  
  const question = quizState.questions[quizState.currentQuestionIndex];
  const questionElement = document.getElementById('question-text');
  const answersContainer = document.getElementById('answers-container');
  const progressBar = document.querySelector('.progress-bar__inner');
  
  // 设置问题文本
  questionElement.textContent = question.text;
  
  // 清除回答选项
  answersContainer.innerHTML = '';
  
  // 创建回答选项
  question.answers.forEach((answer, index) => {
    const answerButton = document.createElement('button');
    answerButton.className = 'answer-btn';
    answerButton.textContent = answer.text;
    
    // 如果已经选择，添加selected类
    if (quizState.answers[question.id] === index) {
      answerButton.classList.add('selected');
    }
    
    // 点击事件
    answerButton.addEventListener('click', () => selectAnswer(question.id, index));
    
    answersContainer.appendChild(answerButton);
  });
  
  // 更新进度条
  const progress = ((quizState.currentQuestionIndex + 1) / quizState.questions.length) * 100;
  progressBar.style.width = `${progress}%`;
  
  // 更新导航按钮状态
  updateNavigationButtons();
}

/**
 * 选择回答的函数
 * @param {number} questionId - 问题ID
 * @param {number} answerIndex - 选择的回答索引
 */
function selectAnswer(questionId, answerIndex) {
  // 保存回答
  quizState.answers[questionId] = answerIndex;
  
  // 给选中的回答添加selected类
  const answerButtons = document.querySelectorAll('.answer-btn');
  answerButtons.forEach((button, index) => {
    if (index === answerIndex) {
      button.classList.add('selected');
    } else {
      button.classList.remove('selected');
    }
  });
  
  // 启用下一题按钮
  document.getElementById('next-question').disabled = false;
}

/**
 * 显示下一题的函数
 */
function nextQuestion() {
  // 如果当前问题未回答，则不前进
  const currentQuestion = quizState.questions[quizState.currentQuestionIndex];
  if (quizState.answers[currentQuestion.id] === undefined) {
    alert('请回答问题');
    return;
  }
  
  // 如果是最后一题，则显示结果
  if (quizState.currentQuestionIndex === quizState.questions.length - 1) {
    finishQuiz();
    return;
  }
  
  // 进入下一题
  quizState.currentQuestionIndex++;
  displayCurrentQuestion();
}

/**
 * 显示上一题的函数
 */
function prevQuestion() {
  if (quizState.currentQuestionIndex > 0) {
    quizState.currentQuestionIndex--;
    displayCurrentQuestion();
  }
}

/**
 * 更新导航按钮状态的函数
 */
function updateNavigationButtons() {
  const prevButton = document.getElementById('prev-question');
  const nextButton = document.getElementById('next-question');
  
  // 第一题时禁用“上一题”按钮
  prevButton.disabled = quizState.currentQuestionIndex === 0;
  
  // 当前问题未回答时禁用“下一题”按钮
  const currentQuestion = quizState.questions[quizState.currentQuestionIndex];
  nextButton.disabled = quizState.answers[currentQuestion.id] === undefined;
  
  // 最后一题时更改“下一题”按钮的文本
  if (quizState.currentQuestionIndex === quizState.questions.length - 1) {
    nextButton.textContent = '查看结果';
  } else {
    nextButton.textContent = '下一题';
  }
}

/**
 * 完成诊断的函数
 */
function finishQuiz() {
  // 确定最适合的AI产品
  // 传递 answers 和 questions 给 determineAnimalType
  const animalType = window.AnimalModule.determineAnimalType(quizState.answers, quizState.questions);
  
  // 亲子模式的处理 (虽然可能不再需要，但保留逻辑以防万一)
  if (quizState.parentMode) {
    if (!quizState.childResults) {
      // 保存孩子的结果
      quizState.childResults = {
        animalType,
        answers: {...quizState.answers}
      };
      
      // 显示家长提示信息
      alert('第一部分已完成。接下来是第二部分。');
      
      // 重置并开始第二部分
      quizState.answers = {};
      quizState.currentQuestionIndex = 0;
      displayCurrentQuestion();
      return;
    } else {
      // 保存家长的结果
      quizState.parentResults = {
        animalType,
        answers: {...quizState.answers}
      };
      
      // 显示双方的结果
      displayComparisonResults();
      return;
    }
  }
  
  // 显示结果
  displayResults(animalType);
}

/**
 * 显示诊断结果的函数
 * @param {string} animalType - 动物类型的ID
 */
function displayResults(animalType) {
  // 获取动物信息
  const animal = window.AnimalModule.getAnimalById(animalType);
  if (!animal) {
    console.error('未找到产品类型:', animalType);
    return;
  }
  
  // 获取结果画面的元素
  const animalTypeElement = document.getElementById('animal-type');
  const animalDescriptionElement = document.getElementById('animal-description');
  const animalImageElement = document.getElementById('result-animal');
  const traitsContainer = document.getElementById('traits-container');
  
  // 显示结果
  animalTypeElement.textContent = `${animal.name}（${animal.type}）`;
  animalDescriptionElement.textContent = animal.description;
  
  // 显示产品图片
  if (animal.image) {
    animalImageElement.innerHTML = `<img src="${animal.image}" alt="${animal.name}" class="animal-icon" style="width: 100%; height: 100%; object-fit: contain; image-rendering: pixelated; filter: grayscale(100%) contrast(120%);">`;
    animalImageElement.style.display = 'block';
    animalImageElement.style.width = '120px';
    animalImageElement.style.height = '120px';
    animalImageElement.style.margin = '0 auto 20px auto';
    animalImageElement.style.backgroundColor = 'transparent';
  } else {
    animalImageElement.innerHTML = `<div class="ai-icon-placeholder">${animal.name.substring(0, 1)}</div>`;
    // 添加样式以美化占位符
    animalImageElement.style.display = 'flex';
    animalImageElement.style.justifyContent = 'center';
    animalImageElement.style.alignItems = 'center';
    animalImageElement.style.fontSize = '4rem';
    animalImageElement.style.fontWeight = 'bold';
    animalImageElement.style.color = '#00FF00';
    animalImageElement.style.backgroundColor = '#000000';
    animalImageElement.style.border = '2px solid #00FF00';
    animalImageElement.style.width = '120px';
    animalImageElement.style.height = '120px';
    animalImageElement.style.margin = '0 auto 20px auto';
  }
  
  // 显示特征
  traitsContainer.innerHTML = '';
  animal.traits.forEach(trait => {
    const traitTag = document.createElement('span');
    traitTag.className = 'trait-tag';
    traitTag.textContent = trait;
    traitsContainer.appendChild(traitTag);
  });
  
  // 显示结果画面
  showScreen('result-screen');
}

/**
 * 显示亲子模式比较结果的函数
 */
function displayComparisonResults() {
  // 结果画面的实现将在未来的阶段进行
  alert('比较模式的结果显示功能正在开发中。');
  
  // 暂时只显示孩子的结果
  displayResults(quizState.childResults.animalType);
}

/**
 * 显示特定画面的函数
 * @param {string} screenId - 要显示的画面ID
 */
function showScreen(screenId) {
  const screens = document.querySelectorAll('.screen');
  screens.forEach(screen => {
    screen.classList.remove('active');
  });
  
  const targetScreen = document.getElementById(screenId);
  if (targetScreen) {
    targetScreen.classList.add('active');
  }
}

/**
 * 显示错误报告的函数
 * @param {string} cause - 错误原因
 * @param {string} impact - 影响
 * @param {string} solution - 解决方法
 */
function showErrorReport(cause, impact, solution) {
  console.error(`<error-report>
原因: ${cause}
影响: ${impact}
解决方法: ${solution}
</error-report>`);
  
  const errorContainer = document.createElement('div');
  errorContainer.className = 'error-report';
  errorContainer.innerHTML = `
    <h3>发生错误</h3>
    <div class="error-content">
      <p><strong>原因:</strong> ${cause}</p>
      <p><strong>影响:</strong> ${impact}</p>
      <p><strong>解决方法:</strong> ${solution}</p>
    </div>
  `;
  
  // 显示在画面上
  const mainElement = document.querySelector('.main');
  if (mainElement) {
    mainElement.prepend(errorContainer);
  } else {
    document.body.prepend(errorContainer);
  }
}

// 导出
window.QuizModule = {
  loadQuestions,
  startQuiz,
  nextQuestion,
  prevQuestion,
  showScreen
};
