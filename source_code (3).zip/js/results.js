/**
 * 诊断结果处理管理模块
 */

// 管理诊断结果状态
const resultState = {
  currentResult: null,  // 当前显示的诊断结果
  savedResults: []      // 保存的诊断结果列表
};

/**
 * 保存诊断结果的函数
 * @param {string} animalType - 动物类型的ID
 * @param {Object} scores - 各动物类型的得分
 * @returns {boolean} 是否保存成功
 */
function saveResult(animalType, scores) {
  try {
    // 创建要保存的结果对象
    const result = {
      id: Date.now().toString(),
      timestamp: new Date().toISOString(),
      animalType,
      scores
    };
    
    // 从本地存储读取现有结果
    const savedResults = loadSavedResults();
    
    // 添加新结果
    savedResults.push(result);
    
    // 保存到本地存储
    localStorage.setItem('animalQuizResults', JSON.stringify(savedResults));
    
    // 更新状态
    resultState.savedResults = savedResults;
    resultState.currentResult = result;
    
    return true;
  } catch (error) {
    console.error('保存诊断结果失败:', error);
    // 显示错误报告
    showErrorReport('保存诊断结果错误', 
                    '无法保存诊断结果。', 
                    '请确认浏览器的Cookie和存储设置已启用。');
    return false;
  }
}

/**
 * 读取已保存的诊断结果的函数
 * @returns {Array} 已保存的诊断结果列表
 */
function loadSavedResults() {
  try {
    const savedResultsJson = localStorage.getItem('animalQuizResults');
    if (!savedResultsJson) {
      return [];
    }
    
    return JSON.parse(savedResultsJson);
  } catch (error) {
    console.error('读取已保存的诊断结果失败:', error);
    return [];
  }
}

/**
 * 生成诊断结果图片的函数
 * @returns {Promise<string>} 图片的数据URL
 */
async function generateResultImage() {
  try {
    // 使用Canvas API获取结果画面的截图
    const resultScreen = document.getElementById('result-screen');
    
    // 需要html2canvas库，动态加载
    if (!window.html2canvas) {
      const script = document.createElement('script');
      script.src = 'https://cdn.jsdelivr.net/npm/html2canvas@1.4.1/dist/html2canvas.min.js';
      script.async = true;
      
      const loadPromise = new Promise((resolve, reject) => {
        script.onload = resolve;
        script.onerror = () => reject(new Error('html2canvas加载失败'));
      });
      
      document.head.appendChild(script);
      await loadPromise;
    }
    
    // 生成图片
    const canvas = await window.html2canvas(resultScreen, {
      backgroundColor: '#ffffff',
      scale: 2,
      logging: false,
      removeContainer: true
    });
    
    // 返回数据URL
    return canvas.toDataURL('image/png');
  } catch (error) {
    console.error('生成结果图片失败:', error);
    // 显示错误报告
    showErrorReport('生成结果图片错误', 
                    '无法创建诊断结果图片。', 
                    '请尝试其他保存方法或截图。');
    return null;
  }
}

/**
 * 将诊断结果保存为图片的函数
 */
async function saveResultAsImage() {
  // 生成图片
  const imageDataUrl = await generateResultImage();
  if (!imageDataUrl) {
    alert('生成图片失败。');
    return;
  }
  
  try {
    // 创建下载链接
    const downloadLink = document.createElement('a');
    downloadLink.href = imageDataUrl;
    downloadLink.download = `动物性格测试结果_${new Date().toISOString().slice(0, 10)}.png`;
    
    // 点击链接开始下载
    downloadLink.click();
  } catch (error) {
    console.error('下载图片失败:', error);
    alert('保存图片失败。请尝试其他方法。');
  }
}

/**
 * 打印诊断结果的函数
 */
function printResult() {
  window.print();
}

/**
 * 在SNS分享诊断结果的函数
 * @param {string} platform - 分享平台 ('twitter', 'line', 'facebook')
 */
function shareResult(platform) {
  // 获取当前动物类型
  const animalTypeElement = document.getElementById('animal-type');
  const resultText = animalTypeElement.textContent;
  
  // 分享文本
  const shareText = `我的性格是「${resultText}」！ 快来试试动物性格测试吧！`;
  
  // 如果可以使用Web Share API
  if (navigator.share) {
    navigator.share({
      title: '动物性格测试结果',
      text: shareText,
      url: window.location.href
    }).catch(error => {
      console.error('分享失败:', error);
    });
    return;
  }
  
  // 如果无法使用Web Share API，则创建各SNS的分享URL
  let shareUrl;
  
  switch (platform) {
    case 'twitter':
      shareUrl = `https://twitter.com/intent/tweet?text=${encodeURIComponent(shareText)}&url=${encodeURIComponent(window.location.href)}`;
      break;
    case 'line':
      shareUrl = `https://social-plugins.line.me/lineit/share?url=${encodeURIComponent(window.location.href)}&text=${encodeURIComponent(shareText)}`;
      break;
    case 'facebook':
      shareUrl = `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(window.location.href)}&quote=${encodeURIComponent(shareText)}`;
      break;
    default:
      alert('不支持该平台。');
      return;
  }
  
  // 在新窗口打开分享URL
  window.open(shareUrl, '_blank', 'width=600,height=400');
}

/**
 * 显示错误报告的函数
 * @param {string} cause - 错误原因
 * @param {string} impact - 影响
 * @param {string} solution - 解决方法
 */
function showErrorReport(cause, impact, solution) {
  console.error(`<error-report>
原因: ${cause}
影响: ${impact}
解决方法: ${solution}
</error-report>`);
  
  const errorContainer = document.createElement('div');
  errorContainer.className = 'error-report';
  errorContainer.innerHTML = `
    <h3>发生错误</h3>
    <div class="error-content">
      <p><strong>原因:</strong> ${cause}</p>
      <p><strong>影响:</strong> ${impact}</p>
      <p><strong>解决方法:</strong> ${solution}</p>
    </div>
  `;
  
  // 显示在画面上
  const mainElement = document.querySelector('.main');
  if (mainElement) {
    mainElement.prepend(errorContainer);
  } else {
    document.body.prepend(errorContainer);
  }
}

// 导出
window.ResultsModule = {
  saveResult,
  loadSavedResults,
  saveResultAsImage,
  printResult,
  shareResult
};
