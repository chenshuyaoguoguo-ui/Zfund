/**
 * AI产品数据管理模块
 */

// 存储AI产品数据的变量
let animalData = null;

/**
 * 加载AI产品数据的函数
 * @returns {Promise} 加载数据的Promise
 */
async function loadAnimalData() {
  try {
    const response = await fetch('data/animals.json');
    if (!response.ok) {
      throw new Error('加载数据失败');
    }
    const data = await response.json();
    animalData = data.animals;
    return animalData;
  } catch (error) {
    console.error('数据加载错误:', error);
    showErrorReport('数据加载错误', '无法显示结果', '请刷新页面或稍后重试');
    return [];
  }
}

/**
 * 获取特定AI产品信息的函数
 * @param {string} id - 产品ID
 * @returns {Object|null} 信息对象
 */
function getAnimalById(id) {
  if (!animalData) {
    console.error('数据尚未加载');
    return null;
  }
  return animalData.find(item => item.id === id) || null;
}

/**
 * 核心算法：根据回答决定最适合的AI产品
 * @param {Object} userAnswers - 用户回答 { questionId: answerIndex }
 * @param {Array} questions - 问题列表
 * @returns {string} 最适合的产品ID
 */
function determineAnimalType(userAnswers, questions) {
  // 1. 统计 A/B/C/D 的数量
  const counts = { A: 0, B: 0, C: 0, D: 0 };
  const qAnswers = {}; // 方便查询：qAnswers[questionId] = 'A'/'B'/'C'/'D'

  for (const [qId, aIndex] of Object.entries(userAnswers)) {
    const question = questions.find(q => q.id == qId);
    if (question && question.answers[aIndex]) {
      const value = question.answers[aIndex].value;
      counts[value] = (counts[value] || 0) + 1;
      qAnswers[qId] = value;
    }
  }

  console.log('Counts:', counts);
  console.log('Answers:', qAnswers);

  // 2. 判定主导轴 (>= 4)
  // 如果有并列，进入混合判定（实际上逻辑中混合判定是兜底或特定条件）
  // 我们先按逻辑顺序判断

  // 辅助函数：获取某题的选项值
  const getAns = (qid) => qAnswers[qid];
  // 辅助函数：某题是否选了特定值
  const isAns = (qid, val) => qAnswers[qid] === val;
  // 辅助函数：某题是否没选特定值
  const notAns = (qid, val) => qAnswers[qid] !== val;

  // --- 逻辑判断开始 ---

  // 🧠 理性 / 结构系（A 主导）
  if (counts.A >= 4 && counts.A >= counts.B && counts.A >= counts.C && counts.A >= counts.D) {
    // 1. Hyperknow
    // A 为最高 (已满足) 且 第 1、3、9、10 题中 A ≥ 3 次 且 D ≤ 1
    let aCountSpecific = 0;
    if (isAns(1, 'A')) aCountSpecific++;
    if (isAns(3, 'A')) aCountSpecific++;
    if (isAns(9, 'A')) aCountSpecific++;
    if (isAns(10, 'A')) aCountSpecific++;
    
    if (aCountSpecific >= 3 && counts.D <= 1) return 'hyperknow';

    // 2. Kimi
    // A 为最高 (已满足) 但 第 7、8 题偏 B / C 且 情绪选项（D）不为 0
    const q7 = getAns(7);
    const q8 = getAns(8);
    if ((q7 === 'B' || q7 === 'C' || q8 === 'B' || q8 === 'C') && counts.D > 0) return 'kimi';

    // 3. Typeless
    // A 与 C 接近（差值 ≤ 1）且 第 5 或第 9 题选 A 且 第 6 题不选 B
    if (Math.abs(counts.A - counts.C) <= 1 && (isAns(5, 'A') || isAns(9, 'A')) && notAns(6, 'B')) return 'typeless';
    
    // 如果是 A 主导但没命中上面，默认归为 Kimi 或 Typeless? 逻辑没说，暂且继续
  }

  // ⚙️ 行动 / 效率系（B 主导）
  if (counts.B >= 4 && counts.B >= counts.A && counts.B >= counts.C && counts.B >= counts.D) {
    // 4. Manus
    // B ≥ 4 且为最高 (已满足) 第 1、5、10 题中 B ≥ 2 且 C ≤ 2
    let bCountSpecific = 0;
    if (isAns(1, 'B')) bCountSpecific++;
    if (isAns(5, 'B')) bCountSpecific++;
    if (isAns(10, 'B')) bCountSpecific++;

    if (bCountSpecific >= 2 && counts.C <= 2) return 'manus';

    // 5. ChatCut
    // B 为最高 (已满足) 且 第 2、5、9 题偏 B 且 A ≤ 2
    let bCountSpecific2 = 0;
    if (isAns(2, 'B')) bCountSpecific2++;
    if (isAns(5, 'B')) bCountSpecific2++;
    if (isAns(9, 'B')) bCountSpecific2++;

    if (bCountSpecific2 >= 1 && counts.A <= 2) return 'chatcut'; // "偏 B" 理解为至少有一个？或者大部分？假设至少1个或更多

    // 6. OpusClip
    // B 与 C 接近（差值 ≤ 1）且 第 4 或第 9 题选 C 且 第 10 题不选 A
    if (Math.abs(counts.B - counts.C) <= 1 && (isAns(4, 'C') || isAns(9, 'C')) && notAns(10, 'A')) return 'opusclip';
  }

  // 🎨 创意 / 生成系（C 主导）
  if (counts.C >= 4 && counts.C >= counts.A && counts.C >= counts.B && counts.C >= counts.D) {
    // 7. Genspark
    // C ≥ 4 且为最高 (已满足) 第 1、3、10 题中 C ≥ 2 且 B ≤ 2
    let cCountSpecific = 0;
    if (isAns(1, 'C')) cCountSpecific++;
    if (isAns(3, 'C')) cCountSpecific++;
    if (isAns(10, 'C')) cCountSpecific++;

    if (cCountSpecific >= 2 && counts.B <= 2) return 'genspark';

    // 8. Pollo AI
    // C 为最高 (已满足) 且 第 4 或第 7 题选 C 且 第 6 题不选 D
    if ((isAns(4, 'C') || isAns(7, 'C')) && notAns(6, 'D')) return 'polloai';

    // 9. HeyGen
    // C 与 D 接近（差值 ≤ 1）且 第 8 或第 9 题选 D 且 第 10 题选 C 或 D
    if (Math.abs(counts.C - counts.D) <= 1 && (isAns(8, 'D') || isAns(9, 'D')) && (isAns(10, 'C') || isAns(10, 'D'))) return 'heygen';
  }

  // 🤍 情绪 / 共情系（D 主导）
  if (counts.D >= 4 && counts.D >= counts.A && counts.D >= counts.B && counts.D >= counts.C) {
    // 10. Macaron
    // D ≥ 4 且为最高 (已满足) 第 3、6、7、10 题中 D ≥ 3
    let dCountSpecific = 0;
    if (isAns(3, 'D')) dCountSpecific++;
    if (isAns(6, 'D')) dCountSpecific++;
    if (isAns(7, 'D')) dCountSpecific++;
    if (isAns(10, 'D')) dCountSpecific++;

    if (dCountSpecific >= 3) return 'macaron';

    // 11. YouWare
    // D 为最高或与 A/B 并列 且 第 4 题选 C 且 第 8 题选 D
    // D最高已满足，或者并列也可能进入这里（如果前面的if没拦截）
    if (isAns(4, 'C') && isAns(8, 'D')) return 'youware';
  }
  
  // 检查 YouWare 的并列情况 (D 与 A 或 B 并列)
  if ((counts.D === counts.A || counts.D === counts.B) && counts.D >= counts.C) {
      if (isAns(4, 'C') && isAns(8, 'D')) return 'youware';
  }

  // 四、兜底规则（防止无结果）
  // 最高轴 + 次高轴组合判定
  const sortedAxes = Object.entries(counts).sort((a, b) => b[1] - a[1]);
  const first = sortedAxes[0][0];
  const second = sortedAxes[1][0];
  const combo = [first, second].sort().join(''); // AC, AD, BC, BD, CD ...

  if (combo === 'AC') return 'typeless';
  if (combo === 'AD') return 'youware';
  if (combo === 'BC') return 'opusclip';
  if (combo === 'BD') return 'manus';
  if (combo === 'CD') return 'heygen';
  
  // 如果还是没有（比如 AB），默认返回最高分对应的典型
  if (first === 'A') return 'kimi';
  if (first === 'B') return 'manus';
  if (first === 'C') return 'genspark';
  if (first === 'D') return 'macaron';

  return 'kimi'; // 绝对兜底
}

/**
 * 显示错误报告的函数
 */
function showErrorReport(cause, impact, solution) {
  const errorContainer = document.createElement('div');
  errorContainer.className = 'error-report';
  errorContainer.innerHTML = `
    <h3>发生错误</h3>
    <div class="error-content">
      <p><strong>原因:</strong> ${cause}</p>
      <p><strong>影响:</strong> ${impact}</p>
      <p><strong>解决方法:</strong> ${solution}</p>
    </div>
  `;
  
  const mainElement = document.querySelector('.main');
  if (mainElement) {
    mainElement.prepend(errorContainer);
  } else {
    document.body.prepend(errorContainer);
  }
}

// 导出
window.AnimalModule = {
  loadAnimalData,
  getAnimalById,
  determineAnimalType
};
