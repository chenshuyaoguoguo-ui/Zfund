/**
 * AI产品测试应用的主脚本
 */

// 应用初始化函数
async function initApp() {
  try {
    // 加载数据
    await Promise.all([
      window.AnimalModule.loadAnimalData(),
      window.QuizModule.loadQuestions()
    ]);
    
    // 设置事件监听器
    setupEventListeners();
    
    // 隐藏加载显示
    hideLoading();
    
  } catch (error) {
    console.error('应用初始化失败:', error);
    // 显示错误报告
    showErrorReport('应用初始化错误', 
                    '无法加载应用启动所需的数据。', 
                    '请刷新页面或尝试使用其他浏览器。');
  }
}

// 设置事件监听器
function setupEventListeners() {
  // 开始测试按钮
  document.getElementById('start-quiz').addEventListener('click', () => {
    window.QuizModule.startQuiz(false);
  });
  
  // 亲子模式按钮 (虽然隐藏了，但保留逻辑以防万一)
  const parentModeBtn = document.getElementById('parent-mode');
  if (parentModeBtn) {
    parentModeBtn.addEventListener('click', () => {
      window.QuizModule.showScreen('parent-info-screen');
    });
  }
  
  // 开始亲子模式按钮
  document.getElementById('start-parent-mode').addEventListener('click', () => {
    window.QuizModule.startQuiz(true);
  });
  
  // 从亲子模式说明返回按钮
  document.getElementById('back-to-start').addEventListener('click', () => {
    window.QuizModule.showScreen('start-screen');
  });
  
  // 下一题按钮
  document.getElementById('next-question').addEventListener('click', () => {
    window.QuizModule.nextQuestion();
  });
  
  // 上一题按钮
  document.getElementById('prev-question').addEventListener('click', () => {
    window.QuizModule.prevQuestion();
  });
  
  // 保存结果按钮
  document.getElementById('save-result').addEventListener('click', () => {
    window.ResultsModule.saveResultAsImage();
  });
  
  // 打印结果按钮
  document.getElementById('print-result').addEventListener('click', () => {
    window.ResultsModule.printResult();
  });
  
  // 分享结果按钮
  document.getElementById('share-result').addEventListener('click', () => {
    // 显示分享菜单（计划实现）
    // 作为临时实现，使用 Web Share API
    if (navigator.share) {
      const animalTypeElement = document.getElementById('animal-type');
      const resultText = animalTypeElement.textContent;
      
      navigator.share({
        title: '真格AI产品适配测试结果',
        text: `最适合我的AI产品是「${resultText}」！\n大家也来测测你最适合哪个真格AI产品吧！`,
        url: window.location.href
      })
      .catch((error) => console.log('分享失败', error));
    } else {
      alert('您的浏览器不支持分享功能。\n请截图分享！');
    }
  });
  
  // 重试按钮
  document.getElementById('retry-quiz').addEventListener('click', () => {
    // 重新加载页面或重置状态
    location.reload();
  });
}

// 隐藏加载画面
function hideLoading() {
  const loadingElement = document.getElementById('loading');
  if (loadingElement) {
    loadingElement.style.display = 'none';
  }
}

// 显示错误报告
function showErrorReport(title, message, solution) {
  // 简单的错误显示
  alert(`${title}\n${message}\n${solution}`);
}

// 暴露给全局
window.initApp = initApp;
